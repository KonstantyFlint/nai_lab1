#include <iostream>
#include <conio.h>
#include <math.h>

#include "canvas.h"

int main()
{
	CANVAS can;
	can.setFontSize(9);
	can.resizeConsole(700,700);
	can.updateSizes();
	can.readConsoleSizes();
	LETTER let;let.pos.x=can.visWIDTH/2,let.pos.y=can.visHEIGHT/2;
	
	can.render(let);
	
	char in;
	while(in=getch())
	{
		switch(in)
		{
			case 'e': 	let.angl+=(double)M_PI/36;break;
			case 'q':	let.angl-=(double)M_PI/36;break;
			
			case 'w':	let.pos.y-=5;break;
			case 's':	let.pos.y+=5;break;
			case 'a':	let.pos.x-=5;break;
			case 'd':	let.pos.x+=5;break;
			
			case 'u':	let.ry+=5;break;
			case 'j':	let.ry-=5;break;
			case 'h':	let.rx+=5;break;
			case 'k':	let.rx-=5;break;
			
			case 'y':	let.width-=1;break;
			case 'i':	let.width+=1;break;
			
			case 'f':	let.cut-=0.02;break;
			case 'g':	let.cut+=0.02;break;
		}
		can.clear();
		can.readConsoleSizes();
		can.updateSizes();
		can.render(let,1);
		can.print();
	}
}
