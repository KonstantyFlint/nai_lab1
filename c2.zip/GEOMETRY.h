#ifndef POINT_H
#define POINT_H

#include <math.h>
#include <iostream>
namespace GEO
{
	struct POINT
	{
		double x;
		double y;
		POINT();
		POINT(double _x, double _y);
		POINT translate(POINT P2);
		POINT translate(double _x, double _y);
		POINT stretch(double x1, double y1, double x2, double y2);
		POINT rotate(double _alpha);
	};
	
	struct ELLIPSE
	{
		POINT O;
		double rx;
		double ry;
		double angle;
		ELLIPSE(double,double);
		ELLIPSE(double,double,double,double);
	};
	
	struct LETTER
	{
		LETTER();
		POINT pos;
		bool exists(double x, double y);	//funkcja sprawdzaj�ca, czy dany punkt le�y na literze
		double rx;
		double ry;
		double angl;
		double cut;
		double width;
	};
	
	double dist(POINT,POINT);
	double dist(POINT,ELLIPSE);
}
#endif
