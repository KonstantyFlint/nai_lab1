#include "CANVAS.h"

void setCursor(int a, int b)
{
	COORD p = {a,b};
    SetConsoleCursorPosition( GetStdHandle( STD_OUTPUT_HANDLE ), p );
}

CANVAS::CANVAS()
{
	for(int j=0;j<maxHEIGHT;j++)
	for(int i=0;i<maxWIDTH ;i++)
	{
		prev[i][j]=' ';
		grid[i][j]=' ';
	}
	fontSIZE=9;
	readConsoleSizes();
	updateSizes();
}

void CANVAS::clear()
{
	for(int j=0;j<HEIGHT;j++)
	{
		for(int i=0;i<WIDTH;i++)
		{
			grid[i][j]=' ';
		}
	}
}

void CANVAS::render(GEO::LETTER _l, bool wrap)
{
	if(!wrap)
	{
		render(_l);
		return;
	}
	
	int dx=visWIDTH;
	int dy=visHEIGHT;
	_l.pos.x-=((int)_l.pos.x/visWIDTH)*visWIDTH;
	_l.pos.y-=((int)_l.pos.y/visHEIGHT)*visHEIGHT;
	GEO::POINT REF=_l.pos;
	for(int i=-1;i<=1;i++)
	{
		for(int j=-1;j<=1;j++)
		{
			GEO::POINT P=REF.translate(i*dx,j*dy);
			_l.pos=P;
			render(_l);
		}
	}
}

void CANVAS::render(GEO::LETTER _l)
{
	GEO::POINT P=_l.pos;
	double dist=std::max(_l.rx,_l.ry)+_l.width/2+5;
	
	GEO::POINT pmin=	P.translate( dist, dist).stretch(visWIDTH,visHEIGHT,WIDTH,HEIGHT);
	GEO::POINT pmax=	P.translate(-dist,-dist).stretch(visWIDTH,visHEIGHT,WIDTH,HEIGHT);
	
	double xmin=std::max((int)pmin.x,0);
	double ymin=std::max((int)pmin.y,0);
	double xmax=std::min((int)pmax.x,WIDTH);
	double ymax=std::min((int)pmax.y,HEIGHT);
	
	for(int j=ymin;j<ymax;j++)
	{
		for(int i=xmin;i<xmax;i++)
		{
			P=GEO::POINT(i,j);
			P=P.stretch(WIDTH,HEIGHT,visWIDTH,visHEIGHT);
			
			if(_l.exists(P.x,P.y))
				grid[i][j]=219;
		}
	}
	
	
}

void CANVAS::print()
{
	for(int j=0;j<HEIGHT;j++)
	{
		for(int i=0;i<WIDTH;i++)
		{
			if(grid[i][j]!=prev[i][j])
			{
				setCursor(i,j);
				std::cout<<grid[i][j];
				prev[i][j]=grid[i][j];
			}	
		}
	}
	setCursor(0,0);
	setCursor(WIDTH-1,HEIGHT-1);
}

void CANVAS::updateSizes()
{
	fontHEIGHT=fontSIZE;
	fontWIDTH=fontSIZE*34/72;
	WIDTH =visWIDTH/fontWIDTH;
	HEIGHT=visHEIGHT/fontHEIGHT;
}

void CANVAS::readConsoleSizes()
{
	CONSOLE_SCREEN_BUFFER_INFO csbi;
    int columns, rows;
    GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi);
    WIDTH= csbi.srWindow.Right - csbi.srWindow.Left + 1;
    HEIGHT= csbi.srWindow.Bottom - csbi.srWindow.Top + 1;
    
	visWIDTH=WIDTH*fontWIDTH;
	visHEIGHT=HEIGHT*fontHEIGHT;
}

void CANVAS::setFontSize(int s)
{
	fontWIDTH=s*34/72;
	fontHEIGHT=s;
	
	CONSOLE_FONT_INFOEX cfi;
	cfi.cbSize = sizeof(cfi);
	cfi.nFont = 0;
	cfi.dwFontSize.X = fontWIDTH; 
	cfi.dwFontSize.Y = fontHEIGHT;
	cfi.FontFamily = FF_DONTCARE;
	cfi.FontWeight = FW_NORMAL;
	std::wcscpy(cfi.FaceName, L"Consolas");
	SetCurrentConsoleFontEx(GetStdHandle(STD_OUTPUT_HANDLE), FALSE, &cfi);
}

void CANVAS::resizeConsole(int _w, int _h)
{
	visWIDTH=_w;
	visHEIGHT=_h;
	WIDTH=visWIDTH/fontWIDTH;
	HEIGHT=visHEIGHT/fontHEIGHT;
	
	HANDLE 	HHH=GetStdHandle(STD_OUTPUT_HANDLE);
	
	_SMALL_RECT Rect; 
    Rect.Top = 0;
    Rect.Left = 0; 
    Rect.Bottom = visWIDTH - 1; 
    Rect.Right = visHEIGHT - 1;
    SetConsoleWindowInfo(HHH, FALSE, &Rect);  
	
	COORD 	CCC = {999,999};
	SetConsoleScreenBufferSize(HHH,CCC);
}
