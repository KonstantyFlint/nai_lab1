#include "GEOMETRY.h"
namespace GEO
{
	POINT::POINT()
	{
		POINT(0,0);
	}
	
	POINT::POINT(double _x, double _y)
	{
		x=_x;
		y=_y;
	}
	
	POINT POINT::translate(POINT P2)
	{
		translate(P2.x,P2.y);
	}
	
	POINT POINT::translate(double _x, double _y)
	{
		POINT ret(x-_x,y-_y);
		return ret;
	}
	
	POINT POINT::stretch(double x1, double y1, double x2, double y2)
	{
		POINT ret(x/x1*x2,y/y1*y2);
		return ret;
	}
	
	POINT POINT::rotate(double _a)
	{
		double q=sin(_a);
		double p=cos(_a);
		double _x=p*x+q*y;
		double _y=q*x-p*y;
		POINT ret(_x,_y);
		return ret;
	}
	
	LETTER::LETTER()
	{
		pos=POINT(0,0);
		rx=120;
		ry=150;
		angl=0;
		cut=M_PI/2;
		width=20;
	}
	
	bool LETTER::exists(double _x, double _y)
	{
		POINT P(_x,_y);
		P=P.translate(pos.x,pos.y);
		P=P.rotate(angl);
		_x=P.x;
		_y=P.y;
		
		double w=width/2;
		double miss=cut/2;
		if(miss<0)miss=0;
		if(_y<0)_y*=-1;
		
		if(_x/sqrt(_x*_x+_y*_y)>cos(miss)){return 0;}
		
		double r1=ry+w;
		double r2=rx+w;
		double r3=ry-w;
		double r4=rx-w;
		if(								(_x*_x*r1*r1+_y*_y*r2*r2<=r1*r1*r2*r2)
		&&	((r1<width)||(r2<width)||	(_x*_x*r3*r3+_y*_y*r4*r4>=r3*r3*r4*r4)))
				return 1;
		else	return 0;
	}
	
	ELLIPSE::ELLIPSE(double _x,double _y,double _rx,double _ry)
	{
		O=POINT(_x,_y);
		angle=0;
		rx=_rx;
		ry=_ry;
	}
	
	ELLIPSE::ELLIPSE(double _rx,double _ry)
	{
		rx=_rx;
		ry=_ry;
	}
		
	double dist(POINT A, POINT B)
	{
		double dx=A.x-B.x;
		double dy=A.y-B.y;
		return sqrt(dx*dx+dy*dy);
	}
	
	double dist(POINT A, ELLIPSE E)
	{
		A=A.translate(E.O);
		A=A.rotate(E.angle);
		E.O=POINT(0,0);
		if(A.x<0)A.x*=-1;
		if(A.y<0)A.y*=-1;
		
		double xmin=0;
		double xmax=E.rx+E.ry+dist(A,E.O);
		
		double LLL  = E.ry*E.ry*A.y;
		double MMM1 = E.rx*E.rx*A.x;
		double MMM2 = E.ry*E.ry-E.rx*E.rx;
		double tx,ty;
		
		while(xmax-xmin>0.1)
		{
			tx=(xmax+xmin)/2;
			//y = b b x y(B) / (a a x(B) - a a x + b b x)
			ty= tx*LLL/(MMM1-tx*MMM2);
			if(tx*tx*E.ry*E.ry+ty*ty*E.rx*E.rx<E.rx*E.rx*E.ry*E.ry)
				xmax=tx;
			else
				xmin=tx;
		}
		POINT B(tx,ty);
		return dist(A,B);
	}
}
