#ifndef CANVAS_H
#define CANVAS_H

#include <windows.h>
#include <iostream>
#include <math.h>

#include "GEOMETRY.h"
using namespace GEO;

const int maxWIDTH =1000;
const int maxHEIGHT=400;

void setCursor(int a, int b);

class CANVAS
{
	public:
		int fontSIZE;					//rozmiar czcionki
		int visWIDTH;					//dlugosc i szerokosc "ekranu" w pixelach
		int visHEIGHT;
		int fontHEIGHT;					//dlugo�� i szeroko�� czcionki	(NIE DOTYKA�)
		int fontWIDTH;
		int WIDTH;						//dlugosc i szerokosc "ekranu" w znakach(NIE DOTYKA�)
		int HEIGHT;
		
		void render(LETTER l);
		void render(LETTER l, bool wrap);
		void print();
		void readConsoleSizes();
		void updateSizes();
		void setFontSize(int s);
		void resizeConsole(int _w, int _h);
		void clear();
		
		CANVAS();
	private:
		char grid[maxWIDTH][maxHEIGHT];
		char prev[maxWIDTH][maxHEIGHT];
};

#endif
